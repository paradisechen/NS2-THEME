// skylineOS 2 — BrowserScreen.qml (In-Theme Switch 2 Web Browser without leaving Pegasus)
import QtQuick 2.12
import QtQuick.Layouts 1.3
import QtGraphicalEffects 1.0

FocusScope {
    id: browserRoot
    anchors.fill: parent

    property string homeUrl: (api.memory.has("Browser default link") && api.memory.get("Browser default link") !== "")
        ? api.memory.get("Browser default link")
        : "https://www.nintendo.com"
    property string currentUrl: homeUrl
    property string pageTitle: "Nintendo.com"
    property string inputUrl: currentUrl
    property bool isLoading: false
    property bool editingUrl: false
    property bool usingNativeWebView: false
    property var nativeWebView: null
    property var historyStack: []
    property int historyIndex: -1
    property string pageError: ""

    property var defaultBookmarks: [
        { label: "Nintendo", url: "https://www.nintendo.com", isFav: false },
        { label: "Google", url: "https://www.google.com", isFav: false },
        { label: "APKPorts", url: "https://www.apkports.com/games", isFav: false },
        { label: "YouTube", url: "https://www.youtube.com", isFav: false }
    ]
    property var savedFavorites: []
    property var bookmarks: []

    property string heroImageUrl: ""
    ListModel { id: contentBlocksModel }
    ListModel { id: linksModel }
    ListModel { id: mediaCardsModel }

    function loadSavedFavorites() {
        var raw = api.memory.has("BROWSER_FAVORITES") ? String(api.memory.get("BROWSER_FAVORITES")) : "[]";
        var arr = [];
        try {
            var parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) arr = parsed;
        } catch (e) {
            arr = [];
        }
        savedFavorites = arr;
        rebuildBookmarksBar();
    }

    function isCurrentFavorite() {
        for (var i = 0; i < savedFavorites.length; i++) {
            if (savedFavorites[i] && savedFavorites[i].url === currentUrl)
                return true;
        }
        return false;
    }

    function rebuildBookmarksBar() {
        var merged = [];
        var i;
        for (i = 0; i < defaultBookmarks.length; i++) {
            var d = defaultBookmarks[i];
            var starred = false;
            for (var j = 0; j < savedFavorites.length; j++) {
                if (savedFavorites[j] && savedFavorites[j].url === d.url) {
                    starred = true;
                    break;
                }
            }
            merged.push({ label: d.label, url: d.url, isFav: starred });
        }
        for (i = 0; i < savedFavorites.length; i++) {
            var f = savedFavorites[i];
            if (!f || !f.url) continue;
            var dup = false;
            for (var k = 0; k < defaultBookmarks.length; k++) {
                if (defaultBookmarks[k].url === f.url) { dup = true; break; }
            }
            if (!dup) {
                merged.push({ label: f.label || f.url, url: f.url, isFav: true });
            }
        }
        bookmarks = merged;
    }

    function toggleFavorite() {
        var next = [];
        var found = false;
        for (var i = 0; i < savedFavorites.length; i++) {
            var item = savedFavorites[i];
            if (!item || !item.url) continue;
            if (item.url === currentUrl) {
                found = true;
            } else {
                next.push(item);
            }
        }
        if (!found) {
            var lbl = String(pageTitle || "").replace(/\s+/g, " ").trim();
            if (lbl === "" || lbl.indexOf("Connection Issue") === 0) {
                var hm = currentUrl.match(/^https?:\/\/(?:www\.)?([^\/]+)/i);
                lbl = hm ? hm[1] : currentUrl;
            }
            if (lbl.length > 22) lbl = lbl.slice(0, 22);
            next.unshift({ label: lbl, url: currentUrl });
            turnOnSfx.play();
        } else {
            turnOffSfx.play();
        }
        savedFavorites = next;
        api.memory.set("BROWSER_FAVORITES", JSON.stringify(next));
        rebuildBookmarksBar();
    }

    function currentBookmarkIndex() {
        for (var i = 0; i < bookmarks.length; i++) {
            if (browserRoot.currentUrl.indexOf(bookmarks[i].url) === 0)
                return i;
        }
        return -1;
    }

    function canGoBack() {
        if (usingNativeWebView && nativeWebView && nativeWebView.canGoBack) return true;
        return historyIndex > 0;
    }

    function canGoForward() {
        if (usingNativeWebView && nativeWebView && nativeWebView.canGoForward) return true;
        return historyIndex >= 0 && historyIndex < historyStack.length - 1;
    }

    function navigate(rawTarget, pushHistory) {
        if (typeof pushHistory === "undefined") pushHistory = true;
        var target = String(rawTarget || "").trim();
        if (target === "") target = homeUrl;
        if (target.indexOf("http://") !== 0 && target.indexOf("https://") !== 0) {
            if (target.indexOf(".") > 0 && target.indexOf(" ") < 0)
                target = "https://" + target;
            else
                target = "https://www.google.com/search?q=" + encodeURIComponent(target);
        }

        if (pushHistory) {
            var nextHist = historyStack.slice(0, historyIndex + 1);
            if (nextHist.length === 0 || nextHist[nextHist.length - 1] !== target) {
                nextHist.push(target);
            }
            historyStack = nextHist;
            historyIndex = historyStack.length - 1;
        }

        currentUrl = target;
        inputUrl = target;
        editingUrl = false;
        pageError = "";

        if (usingNativeWebView && nativeWebView) {
            nativeWebView.url = target;
        } else {
            fetchPageHtml(target);
        }
    }

    function goBack() {
        if (usingNativeWebView && nativeWebView && nativeWebView.canGoBack) {
            nativeWebView.goBack();
            return;
        }
        if (historyIndex > 0) {
            historyIndex--;
            navigate(historyStack[historyIndex], false);
        } else {
            backSfx.play();
            closeInThemeBrowser();
        }
    }

    function goForward() {
        if (usingNativeWebView && nativeWebView && nativeWebView.canGoForward) {
            nativeWebView.goForward();
            return;
        }
        if (historyIndex < historyStack.length - 1) {
            historyIndex++;
            navigate(historyStack[historyIndex], false);
        }
    }

    function goHome() {
        navSound.play();
        navigate(homeUrl, true);
    }

    function reloadPage() {
        if (usingNativeWebView && nativeWebView) {
            nativeWebView.reload();
        } else {
            fetchPageHtml(currentUrl);
        }
    }

    function decodeEntities(str) {
        if (!str) return "";
        return str
            .replace(/&amp;/g, "&")
            .replace(/&lt;/g, "<")
            .replace(/&gt;/g, ">")
            .replace(/&quot;/g, "\"")
            .replace(/&#39;|&apos;/g, "'")
            .replace(/&nbsp;/g, " ")
            .replace(/&#(\d+);/g, function (_, n) { return String.fromCharCode(parseInt(n, 10)); });
    }

    function stripTags(html) {
        return decodeEntities(String(html || "")
            .replace(/<script[\s\S]*?<\/script>/gi, " ")
            .replace(/<style[\s\S]*?<\/style>/gi, " ")
            .replace(/<[^>]+>/g, " "))
            .replace(/\s{2,}/g, " ")
            .trim();
    }

    function resolveUrl(baseUrl, href) {
        if (!href) return "";
        href = decodeEntities(href.trim());
        if (href.indexOf("#") === 0 || href.indexOf("javascript:") === 0) return "";
        if (href.indexOf("http://") === 0 || href.indexOf("https://") === 0) return href;
        var m = baseUrl.match(/^(https?:\/\/[^\/]+)/i);
        var origin = m ? m[1] : "https://www.nintendo.com";
        if (href.indexOf("//") === 0) return "https:" + href;
        if (href.indexOf("/") === 0) return origin + href;
        return origin + "/" + href;
    }

    function buildFetchUrl(url) {
        // Google search blocks plain XHR with 429; route search queries via DuckDuckGo Lite for clean reader results
        var gm = url.match(/^https?:\/\/(?:www\.)?google\.[^\/]+\/search\?.*?\bq=([^&#]+)/i);
        if (gm && gm[1]) {
            return "https://lite.duckduckgo.com/lite/?q=" + gm[1];
        }
        if (url === "https://www.google.com" || url === "https://www.google.com/" || url === "https://google.com") {
            return "https://lite.duckduckgo.com/lite/";
        }
        if (url === "https://www.youtube.com" || url === "https://www.youtube.com/" || url === "https://youtube.com" || url === "https://m.youtube.com") {
            return "https://www.youtube.com/results?search_query=nintendo+switch+2+gameplay";
        }
        return url;
    }

    function fetchPageHtml(url) {
        isLoading = true;
        pageError = "";
        heroImageUrl = "";
        contentBlocksModel.clear();
        linksModel.clear();
        mediaCardsModel.clear();

        var targetFetch = buildFetchUrl(url);
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState !== XMLHttpRequest.DONE) return;
            isLoading = false;
            if (xhr.status >= 200 && xhr.status < 400 && xhr.responseText) {
                parseHtmlIntoReader(url, xhr.responseText);
            } else {
                pageTitle = "Connection Issue (" + xhr.status + ")";
                pageError = "Could not load " + url + " (HTTP " + xhr.status + "). Check Wi-Fi or tap 'Open Chrome'.";
                populateQuickLinksFallback(url);
            }
        };
        xhr.open("GET", targetFetch);
        xhr.setRequestHeader("Accept", "text/html,application/xhtml+xml");
        xhr.setRequestHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36");
        xhr.send();
    }

    function populateQuickLinksFallback(url) {
        linksModel.append({ linkLabel: "Nintendo Official Site", linkUrl: "https://www.nintendo.com" });
        linksModel.append({ linkLabel: "APKPorts Android Library", linkUrl: "https://www.apkports.com/games" });
        linksModel.append({ linkLabel: "YouTube Videos", linkUrl: "https://www.youtube.com" });
        linksModel.append({ linkLabel: "Web Search (Google / Lite)", linkUrl: "https://www.google.com" });
    }

    function parseHtmlIntoReader(baseUrl, html) {
        var titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
        pageTitle = titleMatch ? stripTags(titleMatch[1]) : baseUrl;

        var ogM = html.match(/<meta[^>]+(?:property=["']og:image["']|name=["']twitter:image["'])[^>]+content=["']([^"']+)["']/i);
        if (ogM && ogM[1]) heroImageUrl = resolveUrl(baseUrl, ogM[1]);

        var imgRe = /<img[^>]+(?:data-src|src)=["']([^"']+)["'][^>]*>/gi;
        var im;
        var seenImg = {};
        while ((im = imgRe.exec(html)) !== null && mediaCardsModel.count < 12) {
            var iu = resolveUrl(baseUrl, im[1]);
            if (!iu || seenImg[iu] || /\.(svg|ico)(\?|$)/i.test(iu) || /(pixel|1x1|spacer|badge)/i.test(iu)) continue;
            seenImg[iu] = true;
            if (heroImageUrl === "") heroImageUrl = iu;
            var altM = im[0].match(/alt=["']([^"']+)["']/i);
            mediaCardsModel.append({ imgUrl: iu, caption: altM ? decodeEntities(altM[1]).slice(0, 64) : pageTitle });
        }

        var metaDesc = html.match(/<meta[^>]+(?:name=["']description["']|property=["']og:description["'])[^>]+content=["']([^"']+)["']/i);
        if (metaDesc && metaDesc[1]) {
            contentBlocksModel.append({
                kind: "heading",
                blockText: decodeEntities(metaDesc[1].trim())
            });
        }

        // If YouTube page, extract videoRenderer entries from ytInitialData
        if (baseUrl.indexOf("youtube.com") >= 0 || baseUrl.indexOf("youtu.be") >= 0) {
            var ytRe = /"videoId":"([A-Za-z0-9_-]{11})"[\s\S]{0,450}?"title":\{"runs":\[\{"text":"([^"\\]*(?:\\.[^"\\]*)*)"\}\]/g;
            var ym;
            var ytSeen = {};
            var ytCount = 0;
            while ((ym = ytRe.exec(html)) !== null && ytCount < 25) {
                var vid = ym[1];
                if (ytSeen[vid]) continue;
                ytSeen[vid] = true;
                var vtitle = decodeEntities(ym[2].replace(/\\"/g, "\"").replace(/\\u0026/g, "&"));
                linksModel.append({
                    linkLabel: "▶ " + vtitle.slice(0, 66),
                    linkUrl: "https://www.youtube.com/watch?v=" + vid
                });
                contentBlocksModel.append({
                    kind: "body",
                    blockText: "Video: " + vtitle + " (https://youtu.be/" + vid + ")"
                });
                ytCount++;
            }
        }

        var cleaned = html
            .replace(/<script[\s\S]*?<\/script>/gi, "")
            .replace(/<style[\s\S]*?<\/style>/gi, "")
            .replace(/<noscript[\s\S]*?<\/noscript>/gi, "");

        var blockRe = /<(h1|h2|h3|p|li)[^>]*>([\s\S]*?)<\/\1>/gi;
        var m;
        var count = contentBlocksModel.count;
        while ((m = blockRe.exec(cleaned)) !== null && count < 45) {
            var tag = m[1].toLowerCase();
            var txt = stripTags(m[2]);
            if (txt.length >= 16) {
                contentBlocksModel.append({
                    kind: (tag === "h1" || tag === "h2" || tag === "h3") ? "heading" : "body",
                    blockText: txt
                });
                count++;
            }
        }

        var linkRe = /<a[^>]+href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
        var seen = {};
        var linkCount = linksModel.count;
        while ((m = linkRe.exec(cleaned)) !== null && linkCount < 45) {
            var resolved = resolveUrl(baseUrl, m[1]);
            var label = stripTags(m[2]);
            if (resolved && label.length >= 2 && !seen[resolved]) {
                seen[resolved] = true;
                linksModel.append({
                    linkLabel: label.slice(0, 72),
                    linkUrl: resolved
                });
                linkCount++;
            }
        }

        if (contentBlocksModel.count === 0 && linksModel.count === 0) {
            contentBlocksModel.append({
                kind: "body",
                blockText: "Page loaded. Tap 'Open Chrome' for full interactive JavaScript rendering or pick a bookmark above."
            });
            populateQuickLinksFallback(baseUrl);
        }
    }

    function tryInitNativeWebView() {
        if (nativeWebView) return;
        var candidates = [
            "import QtQuick 2.12; import QtWebView 1.15; WebView { x: 0; y: 0; width: parent.width; height: parent.height }",
            "import QtQuick 2.12; import QtWebView 1.14; WebView { x: 0; y: 0; width: parent.width; height: parent.height }",
            "import QtQuick 2.12; import QtWebView 1.1; WebView { x: 0; y: 0; width: parent.width; height: parent.height }",
            "import QtQuick 2.12; import QtWebView 1.0; WebView { x: 0; y: 0; width: parent.width; height: parent.height }",
            "import QtQuick 2.12; import QtWebEngine 1.10; WebEngineView { x: 0; y: 0; width: parent.width; height: parent.height }",
            "import QtQuick 2.12; import QtWebEngine 1.8; WebEngineView { x: 0; y: 0; width: parent.width; height: parent.height }",
            "import QtQuick 2.12; import QtWebEngine 1.7; WebEngineView { x: 0; y: 0; width: parent.width; height: parent.height }",
            "import QtQuick 2.12; import QtWebEngine 1.4; WebEngineView { x: 0; y: 0; width: parent.width; height: parent.height }",
            "import QtQuick 2.12; import QtWebEngine 1.0; WebEngineView { x: 0; y: 0; width: parent.width; height: parent.height }",
            "import QtQuick 2.12; import QtWebKit 3.0; WebView { x: 0; y: 0; width: parent.width; height: parent.height }"
        ];
        for (var i = 0; i < candidates.length; i++) {
            try {
                var obj = Qt.createQmlObject(candidates[i], webViewHost, "dynamicWebView_" + i);
                if (obj) {
                    nativeWebView = obj;
                    usingNativeWebView = true;
                    if (currentUrl !== "") obj.url = currentUrl;
                    return;
                }
            } catch (e) {}
        }
        usingNativeWebView = false;
    }

    Connections {
        target: browserRoot.nativeWebView
        ignoreUnknownSignals: true
        onUrlChanged: {
            try {
                if (browserRoot.nativeWebView && browserRoot.nativeWebView.url) {
                    var nextU = browserRoot.nativeWebView.url.toString();
                    if (nextU !== "") browserRoot.inputUrl = nextU;
                }
            } catch (e) {}
        }
        onTitleChanged: {
            try {
                if (browserRoot.nativeWebView && browserRoot.nativeWebView.title)
                    browserRoot.pageTitle = String(browserRoot.nativeWebView.title);
            } catch (e) {}
        }
    }

    Timer {
        interval: 250
        repeat: true
        running: browserRoot.visible && browserRoot.usingNativeWebView && browserRoot.nativeWebView !== null
        onTriggered: {
            try {
                if (typeof nativeWebView.loading === "boolean")
                    browserRoot.isLoading = nativeWebView.loading;
                else if (typeof nativeWebView.loadProgress === "number")
                    browserRoot.isLoading = nativeWebView.loadProgress < 100;
            } catch (e) {}
        }
    }

    Component.onCompleted: {
        loadSavedFavorites();
        tryInitNativeWebView();
    }

    onVisibleChanged: {
        if (visible) {
            loadSavedFavorites();
            if (!usingNativeWebView) tryInitNativeWebView();
            if (historyStack.length === 0) {
                navigate(currentUrl, true);
            } else if (usingNativeWebView && nativeWebView) {
                nativeWebView.url = currentUrl;
            }
            browserRoot.forceActiveFocus();
        }
    }

    Rectangle {
        anchors.fill: parent
        color: theme.main
    }

    // Clean NS2 Simple Nintendo Top Toolbar (Back <, Next >, Home, URL, Star, Close)
    Rectangle {
        id: browserTopBar
        anchors { top: parent.top; left: parent.left; right: parent.right }
        height: vpx(62)
        color: theme.button
        z: 30

        Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: theme.secondary; opacity: 0.35 }

        RowLayout {
            anchors { fill: parent; leftMargin: vpx(14); rightMargin: vpx(14) }
            spacing: vpx(8)

            // Back (<)
            Rectangle {
                Layout.preferredWidth: vpx(38); Layout.preferredHeight: vpx(40)
                width: vpx(38); height: vpx(40); radius: vpx(10)
                color: theme.main
                opacity: browserRoot.canGoBack() ? 1.0 : 0.45
                Text { anchors.centerIn: parent; text: "<"; color: theme.text; font.family: titleFont.name; font.bold: true; font.pixelSize: vpx(18) }
                MouseArea { anchors.fill: parent; onClicked: { navSound.play(); browserRoot.goBack(); } }
            }

            // Next (>)
            Rectangle {
                Layout.preferredWidth: vpx(38); Layout.preferredHeight: vpx(40)
                width: vpx(38); height: vpx(40); radius: vpx(10)
                color: theme.main
                opacity: browserRoot.canGoForward() ? 1.0 : 0.45
                Text { anchors.centerIn: parent; text: ">"; color: theme.text; font.family: titleFont.name; font.bold: true; font.pixelSize: vpx(18) }
                MouseArea { anchors.fill: parent; onClicked: { navSound.play(); browserRoot.goForward(); } }
            }

            // Home (www.nintendo.com)
            Rectangle {
                Layout.preferredWidth: vpx(72); Layout.preferredHeight: vpx(40)
                width: vpx(72); height: vpx(40); radius: vpx(10)
                color: theme.main
                Text { anchors.centerIn: parent; text: tr("Home"); color: theme.text; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.020 * fontScale); font.bold: true }
                MouseArea { anchors.fill: parent; onClicked: browserRoot.goHome() }
            }

            // Clean URL / Search Bar (IME sticky blue highlight cleared on blur/accept)
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: vpx(40)
                height: vpx(40)
                radius: vpx(10)
                color: theme.main
                border.color: browserRoot.editingUrl ? theme.accent : theme.secondary
                border.width: browserRoot.editingUrl ? vpx(2) : vpx(1)

                TextInput {
                    id: addressField
                    anchors { fill: parent; leftMargin: vpx(12); rightMargin: vpx(12) }
                    verticalAlignment: TextInput.AlignVCenter
                    color: theme.text
                    font.family: titleFont.name
                    font.pixelSize: Math.round(screenheight * 0.020 * fontScale)
                    clip: true
                    inputMethodHints: Qt.ImhNoPredictiveText | Qt.ImhNoAutoUppercase
                    selectionColor: activeFocus ? "#441D9BF3" : "transparent"
                    text: browserRoot.inputUrl
                    onTextChanged: browserRoot.inputUrl = text
                    onAccepted: {
                        Qt.inputMethod.commit();
                        deselect();
                        focus = false;
                        Qt.inputMethod.hide();
                        browserRoot.editingUrl = false;
                        browserRoot.navigate(addressField.text, true);
                        browserRoot.forceActiveFocus();
                    }
                    onActiveFocusChanged: {
                        browserRoot.editingUrl = activeFocus;
                        if (!activeFocus) {
                            Qt.inputMethod.commit();
                            deselect();
                        }
                    }
                }

                MouseArea {
                    anchors.fill: parent
                    enabled: !addressField.activeFocus
                    onClicked: {
                        addressField.forceActiveFocus();
                        addressField.selectAll();
                    }
                }
            }

            // Go button
            Rectangle {
                Layout.preferredWidth: vpx(54); Layout.preferredHeight: vpx(40)
                width: vpx(54); height: vpx(40); radius: vpx(10)
                color: theme.accent
                Text { anchors.centerIn: parent; text: tr("Go"); color: "white"; font.family: titleFont.name; font.bold: true; font.pixelSize: Math.round(screenheight * 0.020 * fontScale) }
                MouseArea {
                    anchors.fill: parent
                    onClicked: {
                        Qt.inputMethod.commit();
                        addressField.deselect();
                        addressField.focus = false;
                        Qt.inputMethod.hide();
                        selectSfx.play();
                        browserRoot.navigate(addressField.text, true);
                        browserRoot.forceActiveFocus();
                    }
                }
            }

            // Favorite Star Toggle
            Rectangle {
                Layout.preferredWidth: vpx(44); Layout.preferredHeight: vpx(40)
                width: vpx(44); height: vpx(40); radius: vpx(10)
                color: browserRoot.isCurrentFavorite() ? "#F59E0B" : theme.main
                border.color: browserRoot.isCurrentFavorite() ? "#F59E0B" : theme.secondary
                border.width: vpx(1)
                Text {
                    anchors.centerIn: parent
                    text: browserRoot.isCurrentFavorite() ? "★" : "☆"
                    color: browserRoot.isCurrentFavorite() ? "#FFFFFF" : "#F59E0B"
                    font.pixelSize: vpx(20)
                    font.bold: true
                }
                MouseArea { anchors.fill: parent; onClicked: browserRoot.toggleFavorite() }
            }

            // Close / Exit Browser
            Rectangle {
                Layout.preferredWidth: vpx(84); Layout.preferredHeight: vpx(40)
                width: vpx(84); height: vpx(40); radius: vpx(10)
                color: "#E60012"
                Text { anchors.centerIn: parent; text: tr("B  Close"); color: "white"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.019 * fontScale); font.bold: true }
                MouseArea {
                    anchors.fill: parent
                    onClicked: {
                        Qt.inputMethod.commit();
                        addressField.deselect();
                        addressField.focus = false;
                        Qt.inputMethod.hide();
                        backSfx.play();
                        closeInThemeBrowser();
                    }
                }
            }
        }
    }

    // Unobstructed Full Website Viewport (no overlapping cards/bars when WebView is active!)
    Item {
        id: webViewport
        anchors { top: browserTopBar.bottom; bottom: parent.bottom; left: parent.left; right: parent.right }
        clip: true

        Item {
            id: webViewHost
            anchors.fill: parent
            visible: browserRoot.usingNativeWebView
            onWidthChanged: if (browserRoot.nativeWebView) browserRoot.nativeWebView.width = width
            onHeightChanged: if (browserRoot.nativeWebView) browserRoot.nativeWebView.height = height
        }

        // Visual Web Reader Fallback ONLY when native QtWebView/QtWebEngine is unavailable
        Flickable {
            id: visualWebFlick
            anchors.fill: parent
            anchors.margins: vpx(18)
            visible: !browserRoot.usingNativeWebView
            clip: true
            contentWidth: width
            contentHeight: visualWebCol.implicitHeight + vpx(28)
            boundsBehavior: Flickable.StopAtBounds

            Column {
                id: visualWebCol
                width: visualWebFlick.width
                spacing: vpx(14)

                Text {
                    width: parent.width
                    visible: browserRoot.pageError !== ""
                    text: browserRoot.pageError
                    color: "#EF4444"
                    font.pixelSize: vpx(15)
                    wrapMode: Text.Wrap
                }

                // Clean Website Header Banner
                Rectangle {
                    width: parent.width
                    height: browserRoot.heroImageUrl !== "" ? vpx(190) : vpx(76)
                    radius: vpx(12)
                    clip: true
                    color: theme.button
                    Image {
                        visible: browserRoot.heroImageUrl !== ""
                        anchors.fill: parent
                        source: browserRoot.heroImageUrl
                        fillMode: Image.PreserveAspectCrop
                        asynchronous: true
                    }
                    Rectangle {
                        anchors.fill: parent
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: "#33090D16" }
                            GradientStop { position: 1.0; color: "#DE090D16" }
                        }
                    }
                    Column {
                        anchors { left: parent.left; right: parent.right; bottom: parent.bottom; margins: vpx(18) }
                        spacing: vpx(4)
                        Text {
                            width: parent.width
                            text: browserRoot.isLoading ? tr("Loading page...") : browserRoot.pageTitle
                            color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: vpx(22); font.bold: true; elide: Text.ElideRight
                        }
                        Text {
                            width: parent.width
                            text: browserRoot.currentUrl
                            color: "#CBD5E1"; font.family: titleFont.name; font.pixelSize: vpx(13); elide: Text.ElideRight
                        }
                    }
                }

                // Clean Links Strip
                Flickable {
                    visible: linksModel.count > 0
                    width: parent.width; height: vpx(40); clip: true
                    contentWidth: navPillsRow.implicitWidth + vpx(8); contentHeight: height
                    flickableDirection: Flickable.HorizontalFlick
                    Row {
                        id: navPillsRow; height: parent.height; spacing: vpx(8)
                        Repeater {
                            model: linksModel
                            delegate: Rectangle {
                                visible: index < 14; height: vpx(36)
                                width: Math.min(vpx(220), navLinkTxt.implicitWidth + vpx(24))
                                radius: vpx(8); color: theme.button; anchors.verticalCenter: parent.verticalCenter
                                Text { id: navLinkTxt; anchors { fill: parent; leftMargin: vpx(12); rightMargin: vpx(12) } verticalAlignment: Text.AlignVCenter; text: model.linkLabel; color: theme.text; font.family: titleFont.name; font.pixelSize: vpx(13); elide: Text.ElideRight }
                                MouseArea { anchors.fill: parent; onClicked: { selectSfx.play(); browserRoot.navigate(model.linkUrl, true); } }
                            }
                        }
                    }
                }

                Repeater {
                    model: contentBlocksModel
                    delegate: Rectangle {
                        width: visualWebCol.width
                        height: blkRichTxt.implicitHeight + vpx(20)
                        radius: vpx(10)
                        color: model.kind === "heading" ? theme.button : "transparent"
                        Text {
                            id: blkRichTxt
                            anchors { fill: parent; margins: vpx(10) }
                            text: model.blockText
                            color: model.kind === "heading" ? theme.accent : theme.text
                            font.family: titleFont.name
                            font.pixelSize: model.kind === "heading" ? vpx(20) : vpx(16)
                            font.bold: model.kind === "heading"
                            wrapMode: Text.Wrap
                            lineHeight: 1.42
                        }
                    }
                }
            }
        }
    }

    Keys.onUpPressed: {
        if (!browserRoot.editingUrl && !browserRoot.usingNativeWebView)
            visualWebFlick.contentY = Math.max(0, visualWebFlick.contentY - vpx(100));
    }
    Keys.onDownPressed: {
        if (!browserRoot.editingUrl && !browserRoot.usingNativeWebView) {
            var maxY = Math.max(0, visualWebFlick.contentHeight - visualWebFlick.height);
            visualWebFlick.contentY = Math.min(maxY, visualWebFlick.contentY + vpx(100));
        }
    }
    Keys.onBackPressed: {
        event.accepted = true;
        if (browserRoot.editingUrl) {
            Qt.inputMethod.commit(); addressField.deselect(); addressField.focus = false; Qt.inputMethod.hide();
            browserRoot.editingUrl = false; browserRoot.forceActiveFocus();
        } else {
            browserRoot.goBack();
        }
    }
    Keys.onEscapePressed: {
        event.accepted = true;
        if (browserRoot.editingUrl) {
            Qt.inputMethod.commit(); addressField.deselect(); addressField.focus = false; Qt.inputMethod.hide();
            browserRoot.editingUrl = false; browserRoot.forceActiveFocus();
        } else {
            backSfx.play(); closeInThemeBrowser();
        }
    }
    Keys.onReleased: {
        if (typeof root !== "undefined" && typeof root.handleGlobalSleepCombo === "function") root.handleGlobalSleepCombo(event.key, false);
    }

    Keys.onPressed: {
        if (typeof root !== "undefined" && typeof root.handleGlobalSleepCombo === "function" && root.handleGlobalSleepCombo(event.key, true)) { event.accepted = true; return; }
        if (browserRoot.editingUrl) {
            if ((api.keys.isCancel(event) || event.key === Qt.Key_Back || event.key === Qt.Key_Escape) && !event.isAutoRepeat) { event.accepted = true; Qt.inputMethod.commit(); addressField.deselect(); addressField.focus = false; Qt.inputMethod.hide(); browserRoot.editingUrl = false; browserRoot.forceActiveFocus(); }
            return;
        }
        if ((api.keys.isCancel(event) || event.key === Qt.Key_Back || event.key === Qt.Key_Escape || event.key === Qt.Key_B || event.key === Qt.Key_Backspace) && !event.isAutoRepeat) { event.accepted = true; browserRoot.goBack(); } else if (api.keys.isFilters(event) && !event.isAutoRepeat) {
            event.accepted = true;
            addressField.forceActiveFocus();
            addressField.selectAll();
        } else if (api.keys.isDetails(event) && !event.isAutoRepeat) {
            event.accepted = true;
            browserRoot.toggleFavorite();
        } else if (api.keys.isPrevPage(event) && !event.isAutoRepeat) {
            event.accepted = true;
            var curIdx = currentBookmarkIndex();
            if (curIdx < 0) curIdx = 0;
            var prevBm = (curIdx - 1 + bookmarks.length) % bookmarks.length;
            navSound.play();
            browserRoot.navigate(bookmarks[prevBm].url, true);
        } else if (api.keys.isNextPage(event) && !event.isAutoRepeat) {
            event.accepted = true;
            var curBm = currentBookmarkIndex();
            var nextBm = (curBm + 1) % bookmarks.length;
            navSound.play();
            browserRoot.navigate(bookmarks[nextBm].url, true);
        }
    }
}

// skylineOS 2 — StoreScreen.qml (Nintendo eShop — Bigger Controller-Navigable Sidebar, Front Red Border, Real Descriptions, Star Wishlist, Download & Autoplay Video)
import QtQuick 2.12
import QtQuick.Layouts 1.3
import QtGraphicalEffects 1.0

FocusScope {
    id: storeRoot
    anchors.fill: parent

    // Sidebar entries in requested top-down order:
    // Highlights / For You / Wish List / Genres (sub-genres) / Charts / A > Z
    property var sidebarEntries: [
        { id: "highlights",label: "Highlights",      kind: "section",  cat: "" },
        { id: "foryou",    label: "For You",         kind: "section",  cat: "" },
        { id: "nswpedia",  label: "NSWPedia Switch", kind: "section",  cat: "" },
        { id: "wishlist",  label: "Wish List",       kind: "section",  cat: "" },
        { id: "genre_hdr", label: "Genres",          kind: "header",   cat: "" },
        { id: "g_action",  label: "Action",          kind: "genre",    cat: "Action" },
        { id: "g_rpg",     label: "RPG",             kind: "genre",    cat: "RPG" },
        { id: "g_adv",     label: "Adventure",       kind: "genre",    cat: "Adventure" },
        { id: "g_shoot",   label: "Shooter",         kind: "genre",    cat: "Shooter" },
        { id: "g_plat",    label: "Platformer",      kind: "genre",    cat: "Platformer" },
        { id: "g_race",    label: "Racing",          kind: "genre",    cat: "Racing" },
        { id: "g_sim",     label: "Simulation",      kind: "genre",    cat: "Simulation" },
        { id: "g_sports",  label: "Sports",          kind: "genre",    cat: "Sports" },
        { id: "g_indie",   label: "Indie",           kind: "genre",    cat: "Indie" },
        { id: "g_puzzle",  label: "Puzzle",          kind: "genre",    cat: "Puzzle" },
        { id: "charts",    label: "Charts",          kind: "section",  cat: "" },
        { id: "az",        label: "A > Z",           kind: "sort",     cat: "" }
    ]

    property string activeSection: "highlights"
    property string selectedCategory: ""
    property string sortMode: "featured" // "featured" | "title" | "charts"
    property int selectedIndex: 0
    property int sidebarFocusIdx: 0
    property string focusZone: "grid" // "sidebar" | "grid" | "detail" | "fullscreenVideo"
    property int currentPage: 0
    property int itemsPerPage: 6
    property bool isLoading: false
    property bool detailOpen: false
    property var detailGame: ({})
    property string detailDesc: ""
    property string detailDownloadUrl: ""
    property string detailVideoUrl: ""
    property bool detailFetching: false
    property bool fullscreenVideo: false
    property int detailFocusBtn: 0 // 0=Download, 1=Wishlist, 2=Video Preview
    property var videoPlayerObj: null
    property var fullVideoPlayerObj: null
    property var fullWebObj: null
    property var detailWebObj: null
    property string detailYoutubeEmbed: ""

    property var allGamesCache: []
    property var wishlistSlugs: api.memory.has("ESHOP_WISHLIST") ? api.memory.get("ESHOP_WISHLIST") : []

    property bool isDarkPage: (settings.appearanceMode === "Dark") || (settings.appearanceMode === "Auto" && settings.darkMode === "Yes")
    property color pageBg: isDarkPage ? "#18191D" : "#FFFFFF"
    property color sidebarBg: isDarkPage ? "#20222A" : "#F3F4F6"
    property color cardBg: isDarkPage ? "#252832" : "#FFFFFF"
    property color textMain: isDarkPage ? "#F9FAFB" : "#111827"
    property color textMuted: isDarkPage ? "#9CA3AF" : "#4B5563"
    property color dividerColor: isDarkPage ? "#323642" : "#E5E7EB"
    property color eshopRed: "#E60012"

    property var fallbackCatalog: [
        { slug: "hollow-knight", title: "Hollow Knight", version: "1.5.78", portType: "unofficial", category: "Action", dev: "Team Cherry / Port", desc: "Forge your own path in Hollow Knight! An epic action adventure through a vast ruined kingdom of insects and heroes beneath the fading town of Dirtmouth.", cover: "https://cdn.cloudflare.steamstatic.com/steam/apps/367520/header.jpg", video: "https://cdn.cloudflare.steamstatic.com/steam/apps/256705184/movie480.mp4" },
        { slug: "celeste-android", title: "Celeste", version: "1.4.0", portType: "unofficial", category: "Platformer", dev: "Maddy Makes Games / Port", desc: "Help Madeline survive her inner demons on her journey to the top of Celeste Mountain, in this super-tight handcrafted platformer with 700+ screens.", cover: "https://cdn.cloudflare.steamstatic.com/steam/apps/504230/header.jpg", video: "https://cdn.cloudflare.steamstatic.com/steam/apps/256706725/movie480.mp4" },
        { slug: "cuphead-android", title: "Cuphead", version: "1.3.4", portType: "unofficial", category: "Action", dev: "Studio MDHR / Port", desc: "Classic run-and-gun action game heavily focused on boss battles. Inspired by 1930s cartoons with hand-drawn cel animation, watercolor backgrounds, and jazz recordings.", cover: "https://cdn.cloudflare.steamstatic.com/steam/apps/268910/header.jpg", video: "https://cdn.cloudflare.steamstatic.com/steam/apps/256696350/movie480.mp4" },
        { slug: "sonic-mania-plus", title: "Sonic Mania Plus", version: "1.05", portType: "unofficial", category: "Platformer", dev: "RSDKv5 Decompilation", desc: "A celebration of classic 2D Sonic built at crisp 60fps widescreen with Encore Mode, Mighty and Ray playable characters, and remixed iconic zones.", cover: "https://cdn.cloudflare.steamstatic.com/steam/apps/584400/header.jpg", video: "https://cdn.cloudflare.steamstatic.com/steam/apps/256692748/movie480.mp4" },
        { slug: "ship-of-harkinian", title: "Ship of Harkinian (OoT)", version: "8.0.6", portType: "unofficial", category: "Adventure", dev: "Harbour Masters", desc: "Experience The Legend of Zelda: Ocarina of Time natively at 60fps+ with widescreen aspect ratio, free right-stick camera, gyro aiming, and HD texture support.", cover: "https://assets.nintendo.com/image/upload/f_auto/q_auto/dpr_1.5/c_scale,w_800/ncom/en_US/games/switch/t/the-legend-of-zelda-skyward-sword-hd-switch/hero", video: "" },
        { slug: "undertale-android", title: "Undertale", version: "1.08", portType: "unofficial", category: "RPG", dev: "Toby Fox / Community", desc: "Welcome to UNDERTALE. In this RPG, you control a human who falls underground into the world of monsters. Now you must find your way out—or stay trapped forever.", cover: "https://cdn.cloudflare.steamstatic.com/steam/apps/391540/header.jpg", video: "https://cdn.cloudflare.steamstatic.com/steam/apps/2040377/movie480.mp4" },
        { slug: "half-life-2-android", title: "Half-Life 2", version: "1.14", portType: "unofficial", category: "Shooter", dev: "nillerusr / Source Engine", desc: "Pick up the crowbar once more as Gordon Freeman in Valve's landmark sci-fi first-person shooter, running natively on Android via the Source Engine port.", cover: "https://cdn.cloudflare.steamstatic.com/steam/apps/220/header.jpg", video: "" },
        { slug: "portal-android", title: "Portal", version: "1.14", portType: "unofficial", category: "Adventure", dev: "nillerusr / Source Engine", desc: "Use the Aperture Science Handheld Portal Device to solve mind-bending spatial physics chambers and outwit GLaDOS natively on handheld Android.", cover: "https://cdn.cloudflare.steamstatic.com/steam/apps/400/header.jpg", video: "" },
        { slug: "tmnt-shredders-revenge", title: "TMNT: Shredder's Revenge", version: "1.2.12", portType: "official", category: "Action", dev: "Tribute Games", desc: "Leonardo, Raphael, Donatello, Michelangelo and Splinter reunite in a rad 80s arcade beat-em-up with gorgeous full-color pixel art and co-op action.", cover: "https://cdn.cloudflare.steamstatic.com/steam/apps/1361510/header.jpg", video: "https://cdn.cloudflare.steamstatic.com/steam/apps/256891322/movie480.mp4" },
        { slug: "stardew-valley", title: "Stardew Valley", version: "1.6.14", portType: "official", category: "Simulation", dev: "ConcernedApe", desc: "Inherit your grandfather's old farm plot in Stardew Valley. Raise animals, grow seasonal crops, explore mysterious caves, and build a new life.", cover: "https://cdn.cloudflare.steamstatic.com/steam/apps/413150/header.jpg", video: "https://cdn.cloudflare.steamstatic.com/steam/apps/256660296/movie480.mp4" },
        { slug: "horizon-chase", title: "Horizon Chase Turbo", version: "2.6.0", portType: "official", category: "Racing", dev: "Aquiris", desc: "Classic arcade racing inspired by 90s hits like OutRun and Top Gear with vibrant low-poly visuals, synthwave beats, and split-screen action.", cover: "https://cdn.cloudflare.steamstatic.com/steam/apps/389140/header.jpg", video: "https://cdn.cloudflare.steamstatic.com/steam/apps/256716885/movie480.mp4" },
        { slug: "rocket-league-sideswipe", title: "Rocket League Sideswipe", version: "1.9", portType: "official", category: "Sports", dev: "Psyonix", desc: "Fast-paced 2D car soccer action designed for quick competitive matches with aerial boosts, flips, and crisp controller support.", cover: "https://cdn.cloudflare.steamstatic.com/steam/apps/252950/header.jpg", video: "" },
        { slug: "nsw-zelda-totk", title: "Zelda: Tears of the Kingdom", version: "1.2.1", portType: "switch", sourceSite: "nswpedia", category: "Adventure", dev: "Nintendo / NSWPedia", desc: "Explore the vast land and skies of Hyrule in The Legend of Zelda: Tears of the Kingdom Switch release.", cover: "https://assets.nintendo.com/image/upload/f_auto/q_auto/c_fill,w_800/ncom/en_US/games/switch/t/the-legend-of-zelda-tears-of-the-kingdom-switch/hero", video: "" },
        { slug: "nsw-super-mario-wonder", title: "Super Mario Bros. Wonder", version: "1.0.1", portType: "switch", sourceSite: "nswpedia", category: "Platformer", dev: "Nintendo / NSWPedia", desc: "Expect the unexpected in Super Mario Bros. Wonder as Wonder Flowers transform every course across the Flower Kingdom.", cover: "https://assets.nintendo.com/image/upload/f_auto/q_auto/c_fill,w_800/ncom/en_US/games/switch/s/super-mario-bros-wonder-switch/hero", video: "" },
        { slug: "nsw-mario-kart-8-deluxe", title: "Mario Kart 8 Deluxe", version: "3.0.3", portType: "switch", sourceSite: "nswpedia", category: "Racing", dev: "Nintendo / NSWPedia", desc: "Hit the road with the definitive version of Mario Kart 8 featuring 96 tracks including Booster Course Pass.", cover: "https://assets.nintendo.com/image/upload/f_auto/q_auto/c_fill,w_800/ncom/en_US/games/switch/m/mario-kart-8-deluxe-switch/hero", video: "" },
        { slug: "nsw-metroid-dread", title: "Metroid Dread", version: "2.1.0", portType: "switch", sourceSite: "nswpedia", category: "Action", dev: "MercurySteam / NSWPedia", desc: "Join bounty hunter Samus Aran on Planet ZDR in a tense side-scrolling action-adventure escaping relentless E.M.M.I. robots.", cover: "https://assets.nintendo.com/image/upload/f_auto/q_auto/c_fill,w_800/ncom/en_US/games/switch/m/metroid-dread-switch/hero", video: "" },
        { slug: "nsw-bayonetta-3", title: "Bayonetta 3", version: "1.2.0", portType: "switch", sourceSite: "nswpedia", category: "Action", dev: "PlatinumGames / NSWPedia", desc: "Wield wicked weaves and Demon Masquerade abilities across stylized action set pieces.", cover: "https://assets.nintendo.com/image/upload/f_auto/q_auto/c_fill,w_800/ncom/en_US/games/switch/b/bayonetta-3-switch/hero", video: "" },
        { slug: "nsw-balatro-switch", title: "Balatro", version: "1.0.4", portType: "switch", sourceSite: "nswpedia", category: "Puzzle", dev: "LocalThunk / NSWPedia", desc: "The hypnotic poker roguelike deckbuilder combining illegal poker hands with game-changing Jokers.", cover: "https://cdn.cloudflare.steamstatic.com/steam/apps/2379780/header.jpg", video: "" },
        { slug: "nsw-hades-switch", title: "Hades", version: "1.0.3", portType: "switch", sourceSite: "nswpedia", category: "Indie", dev: "Supergiant / NSWPedia", desc: "Defy the god of the dead as you hack and slash out of the Underworld in this award-winning rogue-like dungeon crawler.", cover: "https://cdn.cloudflare.steamstatic.com/steam/apps/1145360/header.jpg", video: "" }
    ]

    ListModel { id: filteredModel }
    ListModel { id: pageGridModel }

    function isWishlisted(slug) {
        for (var i = 0; i < wishlistSlugs.length; i++) {
            if (wishlistSlugs[i] === slug) return true;
        }
        return false;
    }

    function toggleWishlist(slug) {
        if (!slug || slug === "") return;
        var next = wishlistSlugs.slice(0);
        var foundAt = -1;
        for (var i = 0; i < next.length; i++) {
            if (next[i] === slug) { foundAt = i; break; }
        }
        if (foundAt >= 0) { next.splice(foundAt, 1); turnOffSfx.play(); }
        else { next.push(slug); turnOnSfx.play(); }
        wishlistSlugs = next;
        api.memory.set("ESHOP_WISHLIST", next);
        if (activeSection === "wishlist") rebuildGrid();
    }

    function totalPages() {
        return Math.max(1, Math.ceil(filteredModel.count / itemsPerPage));
    }

    function rebuildPageSlice() {
        pageGridModel.clear();
        var tp = totalPages();
        if (currentPage >= tp) currentPage = tp - 1;
        if (currentPage < 0) currentPage = 0;
        var start = currentPage * itemsPerPage;
        var end = Math.min(filteredModel.count, start + itemsPerPage);
        for (var i = start; i < end; i++) {
            pageGridModel.append(filteredModel.get(i));
        }
        if (selectedIndex >= pageGridModel.count) selectedIndex = Math.max(0, pageGridModel.count - 1);
    }

    function rebuildGrid() {
        filteredModel.clear();
        var base = allGamesCache.length > 0 ? allGamesCache : fallbackCatalog;
        var catLower = String(selectedCategory || "").trim().toLowerCase();
        var arr = [];

        for (var i = 0; i < base.length; i++) {
            var g = base[i];
            if (activeSection === "wishlist" && !isWishlisted(g.slug)) continue;
            if (activeSection === "nswpedia" && String(g.sourceSite || "") !== "nswpedia" && String(g.portType || "") !== "switch") continue;
            if (activeSection === "foryou" && g.portType === "official" && i % 2 === 1) continue;
            if (catLower !== "") {
                var c = String(g.category || "APK Port").toLowerCase();
                if (c.indexOf(catLower) < 0 && String(g.desc || "").toLowerCase().indexOf(catLower) < 0 && String(g.title || "").toLowerCase().indexOf(catLower) < 0) continue;
            }
            arr.push(g);
        }

        if (sortMode === "title") {
            arr.sort(function(a, b) {
                var ta = String(a.title || "").toLowerCase();
                var tb = String(b.title || "").toLowerCase();
                return ta < tb ? -1 : (ta > tb ? 1 : 0);
            });
        } else if (sortMode === "charts") {
            arr = arr.slice(0).reverse();
        }

        for (var j = 0; j < arr.length; j++) {
            var it = arr[j];
            filteredModel.append({
                slug: String(it.slug || ""),
                title: String(it.title || ""),
                version: String(it.version || "Latest"),
                portType: String(it.portType || "unofficial"),
                sourceSite: String(it.sourceSite || (it.portType === "switch" ? "nswpedia" : "apkports")),
                category: String(it.category || "Action"),
                dev: String(it.dev || "APKPorts.com"),
                desc: String(it.desc || ""),
                cover: String(it.cover || ""),
                video: String(it.video || "")
            });
        }
        currentPage = 0;
        selectedIndex = 0;
        rebuildPageSlice();
    }

    function activateSidebarEntry(idx) {
        if (idx < 0 || idx >= sidebarEntries.length) return;
        var entry = sidebarEntries[idx];
        if (entry.kind === "header") return;
        sidebarFocusIdx = idx;
        selectSfx.play();
        if (entry.kind === "genre") {
            activeSection = "genres";
            selectedCategory = entry.cat;
            sortMode = "featured";
        } else if (entry.kind === "sort") {
            activeSection = "az";
            selectedCategory = "";
            sortMode = "title";
        } else {
            activeSection = entry.id;
            selectedCategory = "";
            sortMode = (entry.id === "charts") ? "charts" : "featured";
        }
        rebuildGrid();
    }

    function moveSidebar(dir) {
        var next = sidebarFocusIdx;
        for (var s = 0; s < sidebarEntries.length; s++) {
            next = (next + dir + sidebarEntries.length) % sidebarEntries.length;
            if (sidebarEntries[next].kind !== "header") break;
        }
        sidebarFocusIdx = next;
        sidebarList.positionViewAtIndex(sidebarFocusIdx, ListView.Contain);
    }

    function decodeEntities(str) {
        return String(str || "")
            .replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
            .replace(/&quot;/g, "\"").replace(/&#39;|&apos;/g, "'").replace(/&nbsp;/g, " ");
    }

    function cleanHtml(s) {
        return decodeEntities(String(s || ""))
            .replace(/<script[\s\S]*?<\/script>/gi, " ")
            .replace(/<style[\s\S]*?<\/style>/gi, " ")
            .replace(/<[^>]+>/g, " ")
            .replace(/\s+/g, " ")
            .trim();
    }

    function parseApkPortsHtml(html) {
        var results = [];
        var seen = {};
        if (!html || html.length < 40) return results;
        var cardRe = /<a[^>]+href=["'](?:https?:\/\/www\.apkports\.com)?\/game\/([^"'?#\/]+)["'][^>]*>([\s\S]*?)<\/a>/gi;
        var m;
        while ((m = cardRe.exec(html)) !== null && results.length < 60) {
            var slug = m[1].trim();
            if (!slug || seen[slug]) continue;
            var block = m[2];
            var imgM = block.match(/<img[^>]+(?:data-src|src)=["']([^"']+)["']/i);
            var hM = block.match(/<(?:h2|h3|h4|span|div)[^>]*>([^<]{2,64})<\/(?:h2|h3|h4|span|div)>/i);
            var title = hM ? hM[1].replace(/\s+/g, " ").trim() : slug.replace(/-/g, " ");
            if (title.length < 2) continue;
            var verM = block.match(/v?(\d+\.\d+(?:\.\d+)?)/i);
            var cover = imgM ? decodeEntities(imgM[1].trim()) : "";
            if (cover.indexOf("/") === 0) cover = "https://www.apkports.com" + cover;
            seen[slug] = true;
            // Match fallback description if known slug
            var fbDesc = "";
            var fbVid = "";
            var fbCat = "Action";
            for (var f = 0; f < fallbackCatalog.length; f++) {
                if (fallbackCatalog[f].slug === slug || fallbackCatalog[f].title.toLowerCase() === title.toLowerCase()) {
                    fbDesc = fallbackCatalog[f].desc;
                    fbVid = fallbackCatalog[f].video || "";
                    fbCat = fallbackCatalog[f].category;
                    break;
                }
            }
            results.push({
                slug: slug,
                title: title,
                version: verM ? verM[1] : "Latest",
                portType: /official/i.test(block) ? "official" : "unofficial",
                category: fbCat,
                dev: "APKPorts.com",
                desc: fbDesc !== "" ? fbDesc : (title + " Android game port. Select to inspect game synopsis & download directly from APKPorts."),
                cover: cover,
                video: fbVid
            });
        }
        return results;
    }

    function fetchLiveNswPedia() {
        var xhrN = new XMLHttpRequest();
        xhrN.onreadystatechange = function() {
            if (xhrN.readyState !== XMLHttpRequest.DONE) return;
            if (xhrN.status >= 200 && xhrN.status < 400 && xhrN.responseText) {
                var html = xhrN.responseText;
                var added = [];
                var seenN = {};
                var artRe = /<article[^>]*>([\s\S]*?)<\/article>/gi;
                var m;
                while ((m = artRe.exec(html)) !== null && added.length < 36) {
                    var blk = m[1];
                    var linkM = blk.match(/<a[^>]+href=["'](https?:\/\/(?:www\.)?nswpedia\.com\/[^"']+)["'][^>]*>/i);
                    var titleM = blk.match(/<(?:h1|h2|h3)[^>]*>[\s\S]*?([^<>]{3,80})[\s\S]*?<\/(?:h1|h2|h3)>/i);
                    var imgM = blk.match(/<img[^>]+(?:data-src|src)=["']([^"']+)["']/i);
                    if (!linkM || !titleM) continue;
                    var t = cleanHtml(titleM[1]).replace(/NSP\s*\/?\s*XCI.*$/i, "").trim();
                    var slug = "nsw-" + t.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
                    if (!t || seenN[slug]) continue;
                    seenN[slug] = true;
                    added.push({
                        slug: slug,
                        title: t,
                        version: "NSP/XCI",
                        portType: "switch",
                        sourceSite: "nswpedia",
                        category: "Action",
                        dev: "NSWPedia.com",
                        desc: t + " Nintendo Switch release from NSWPedia.com.",
                        cover: imgM ? decodeEntities(imgM[1].trim()) : "",
                        video: "",
                        pageUrl: linkM[1]
                    });
                }
                if (added.length > 0) {
                    var merged = allGamesCache.slice(0);
                    for (var i = 0; i < added.length; i++) {
                        var dup = false;
                        for (var j = 0; j < merged.length; j++) {
                            if (merged[j].slug === added[i].slug) { dup = true; break; }
                        }
                        if (!dup) merged.push(added[i]);
                    }
                    allGamesCache = merged;
                    rebuildGrid();
                }
            }
        };
        xhrN.open("GET", "https://nswpedia.com/");
        xhrN.send();
    }

    function searchYouTubeTrailer(gameTitle) {
        if (!gameTitle) return;
        var expectedTitle = gameTitle;
        var xhrY = new XMLHttpRequest();
        xhrY.onreadystatechange = function() {
            if (xhrY.readyState !== XMLHttpRequest.DONE) return;
            if (!detailOpen || detailGame.title !== expectedTitle) return;
            if (xhrY.status >= 200 && xhrY.status < 400 && xhrY.responseText) {
                var ym = xhrY.responseText.match(/"videoId":"([A-Za-z0-9_-]{11})"/);
                if (ym && ym[1]) {
                    var embedUrl = "https://www.youtube.com/embed/" + ym[1] + "?autoplay=1&mute=0&playsinline=1&vq=small";
                    detailYoutubeEmbed = embedUrl;
                    if (detailVideoUrl === "") detailVideoUrl = embedUrl;
                    tryStartDetailWebVideo(embedUrl);
                }
            }
        };
        xhrY.open("GET", "https://www.youtube.com/results?search_query=" + encodeURIComponent(gameTitle + " gameplay trailer"));
        xhrY.send();
    }

    function tryStartDetailWebVideo(embedUrl) {
        if (!embedUrl || detailWebObj) return;
        var cands = [
            "import QtQuick 2.12; import QtWebView 1.15; WebView { x: 0; y: 0; width: parent.width; height: parent.height }",
            "import QtQuick 2.12; import QtWebView 1.1; WebView { x: 0; y: 0; width: parent.width; height: parent.height }",
            "import QtQuick 2.12; import QtWebView 1.0; WebView { x: 0; y: 0; width: parent.width; height: parent.height }",
            "import QtQuick 2.12; import QtWebEngine 1.8; WebEngineView { x: 0; y: 0; width: parent.width; height: parent.height }"
        ];
        for (var i = 0; i < cands.length; i++) {
            try {
                var o = Qt.createQmlObject(cands[i], videoInlineHost, "eshopYtWeb_" + i);
                if (o) {
                    detailWebObj = o;
                    o.url = embedUrl;
                    return;
                }
            } catch (e) {}
        }
    }

    function fetchLiveApkPorts() {
        fetchLiveNswPedia();
        isLoading = true;
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== XMLHttpRequest.DONE) return;
            isLoading = false;
            if (xhr.status >= 200 && xhr.status < 400 && xhr.responseText) {
                var parsed = parseApkPortsHtml(xhr.responseText);
                if (parsed.length > 0) {
                    // Merge live items with curated fallback catalog (so genres & videos stay populated)
                    var merged = parsed.slice(0);
                    for (var f = 0; f < fallbackCatalog.length; f++) {
                        var exists = false;
                        for (var p = 0; p < merged.length; p++) {
                            if (merged[p].slug === fallbackCatalog[f].slug) { exists = true; break; }
                        }
                        if (!exists) merged.push(fallbackCatalog[f]);
                    }
                    allGamesCache = merged;
                    rebuildGrid();
                    return;
                }
            }
            if (allGamesCache.length === 0) {
                allGamesCache = fallbackCatalog.slice(0);
                rebuildGrid();
            }
        };
        xhr.open("GET", "https://www.apkports.com/games?sort=newest");
        xhr.send();
    }

    function stopInlineOnly() {
        if (detailWebObj) {
            try { detailWebObj.destroy(); } catch (e) {}
            detailWebObj = null;
        }
        if (videoPlayerObj) {
            try { videoPlayerObj.stop(); videoPlayerObj.destroy(); } catch (e) {}
            videoPlayerObj = null;
        }
    }

    function destroyDetailVideo() {
        stopInlineOnly();
        detailYoutubeEmbed = "";
        if (fullWebObj) {
            try { fullWebObj.destroy(); } catch (e) {}
            fullWebObj = null;
        }
        if (fullVideoPlayerObj) {
            try { fullVideoPlayerObj.stop(); fullVideoPlayerObj.destroy(); } catch (e) {}
            fullVideoPlayerObj = null;
        }
    }

    function tryStartDetailVideo(url) {
        destroyDetailVideo();
        if (!url) return;
        if (/\.(mp4|webm|m4v)(\?|$)/i.test(url)) {
            try {
                var qml = 'import QtQuick 2.12; import QtMultimedia 5.9; Video { anchors.fill: parent; fillMode: VideoOutput.PreserveAspectCrop; autoPlay: true; loops: MediaPlayer.Infinite; muted: false; volume: 1.0; source: "' + url.replace(/"/g, "") + '" }';
                videoPlayerObj = Qt.createQmlObject(qml, videoInlineHost, "eshopInlineVideo");
            } catch (e) {
                videoPlayerObj = null;
            }
        } else if (url.indexOf("youtube") >= 0 || url.indexOf("youtu.be") >= 0) {
            var soundUrl = url.replace("mute=1", "mute=0");
            detailYoutubeEmbed = soundUrl;
            tryStartDetailWebVideo(soundUrl);
        }
    }

    function openFullscreenVideo() {
        var targetUrl = detailVideoUrl || detailYoutubeEmbed;
        if (!targetUrl) return;
        stopInlineOnly();
        fullscreenVideo = true;
        focusZone = "fullscreenVideo";
        selectSfx.play();
        if (fullWebObj) {
            try { fullWebObj.destroy(); } catch (e) {}
            fullWebObj = null;
        }
        if (fullVideoPlayerObj) {
            try { fullVideoPlayerObj.stop(); fullVideoPlayerObj.destroy(); } catch (e) {}
            fullVideoPlayerObj = null;
        }
        if (/\.(mp4|webm|m4v)(\?|$)/i.test(targetUrl)) {
            try {
                var qml = 'import QtQuick 2.12; import QtMultimedia 5.9; Video { anchors.fill: parent; fillMode: VideoOutput.PreserveAspectFit; autoPlay: true; loops: MediaPlayer.Infinite; muted: false; volume: 1.0; source: "' + targetUrl.replace(/"/g, "") + '" }';
                fullVideoPlayerObj = Qt.createQmlObject(qml, fullscreenVideoHost, "eshopFullVideo");
            } catch (e) {
                fullVideoPlayerObj = null;
            }
        } else {
            var fsUrl = targetUrl.replace("mute=1", "mute=0");
            var cands = [
                "import QtQuick 2.12; import QtWebView 1.15; WebView { x: 0; y: 0; width: parent.width; height: parent.height }",
                "import QtQuick 2.12; import QtWebView 1.1; WebView { x: 0; y: 0; width: parent.width; height: parent.height }",
                "import QtQuick 2.12; import QtWebView 1.0; WebView { x: 0; y: 0; width: parent.width; height: parent.height }",
                "import QtQuick 2.12; import QtWebEngine 1.8; WebEngineView { x: 0; y: 0; width: parent.width; height: parent.height }"
            ];
            for (var i = 0; i < cands.length; i++) {
                try {
                    var o = Qt.createQmlObject(cands[i], fullscreenVideoHost, "eshopFullYt_" + i);
                    if (o) { fullWebObj = o; o.url = fsUrl; break; }
                } catch (e) {}
            }
        }
    }

    function closeFullscreenVideo() {
        fullscreenVideo = false;
        focusZone = "detail";
        if (fullWebObj) {
            try { fullWebObj.destroy(); } catch (e) {}
            fullWebObj = null;
        }
        if (fullVideoPlayerObj) {
            try { fullVideoPlayerObj.stop(); fullVideoPlayerObj.destroy(); } catch (e) {}
            fullVideoPlayerObj = null;
        }
        if (detailVideoUrl !== "") {
            tryStartDetailVideo(detailVideoUrl);
        } else if (detailYoutubeEmbed !== "") {
            tryStartDetailWebVideo(detailYoutubeEmbed);
        }
        backSfx.play();
    }

    function fetchLiveGameDetail(slug) {
        if (!slug) return;
        detailFetching = true;
        var pageUrl = "https://www.apkports.com/game/" + encodeURIComponent(String(slug));
        detailDownloadUrl = pageUrl + "#download";
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== XMLHttpRequest.DONE) return;
            detailFetching = false;
            if (xhr.status >= 200 && xhr.status < 400 && xhr.responseText) {
                var html = xhr.responseText;
                // Real description: check <meta name="description"> + meaningful <p> paragraphs
                var paras = [];
                var pRe = /<p\b[^>]*>([\s\S]*?)<\/p>/gi;
                var m;
                while ((m = pRe.exec(html)) !== null && paras.length < 4) {
                    var pt = cleanHtml(m[1]);
                    if (pt.length >= 40 && !/apkports|cookie|telegram|discord|privacy/i.test(pt)) {
                        paras.push(pt);
                    }
                }
                if (paras.length > 0) {
                    detailDesc = paras.join("\n\n");
                } else {
                    var md = html.match(/<meta[^>]+(?:name=["']description["']|property=["']og:description["'])[^>]+content=["']([^"']+)["']/i);
                    if (md && md[1]) detailDesc = cleanHtml(md[1]);
                }

                // Extract video if present
                var vidM = html.match(/<(?:video|source)[^>]+src=["']([^"']+\.(?:mp4|webm)[^"']*)["']/i);
                if (vidM && vidM[1]) {
                    detailVideoUrl = decodeEntities(vidM[1]);
                    if (detailVideoUrl.indexOf("/") === 0) detailVideoUrl = "https://www.apkports.com" + detailVideoUrl;
                    tryStartDetailVideo(detailVideoUrl);
                }

                // Extract direct download section or APK link if present
                var dlM = html.match(/<a[^>]+href=["']([^"']*(?:download|\.apk|mediafire|mega\.nz|drive\.google)[^"']*)["']/i);
                if (dlM && dlM[1]) {
                    var dl = decodeEntities(dlM[1].trim());
                    if (dl.indexOf("#") === 0) detailDownloadUrl = pageUrl + dl;
                    else if (dl.indexOf("/") === 0) detailDownloadUrl = "https://www.apkports.com" + dl;
                    else if (dl.indexOf("http") === 0) detailDownloadUrl = dl;
                }
            }
        };
        xhr.open("GET", pageUrl);
        xhr.send();
    }

    function openItemDetail(idx) {
        if (idx < 0 || idx >= pageGridModel.count) return;
        var g = pageGridModel.get(idx);
        detailGame = {
            slug: g.slug, title: g.title, version: g.version, portType: g.portType,
            category: g.category, dev: g.dev, desc: g.desc, cover: g.cover, video: g.video
        };
        detailDesc = g.desc || "";
        detailDownloadUrl = "https://www.apkports.com/game/" + encodeURIComponent(String(g.slug || "")) + "#download";
        detailVideoUrl = g.video || "";
        detailOpen = true;
        fullscreenVideo = false;
        detailFocusBtn = 0;
        focusZone = "detail";
        selectSfx.play();
        if (detailVideoUrl !== "") { tryStartDetailVideo(detailVideoUrl); }
        else { searchYouTubeTrailer(g.title); }
        if (g.sourceSite !== "nswpedia") fetchLiveGameDetail(g.slug);
    }

    function openDownloadPage() {
        var u = detailDownloadUrl !== "" ? detailDownloadUrl : ("https://www.apkports.com/game/" + encodeURIComponent(String(detailGame.slug || "")) + "#download");
        selectSfx.play();
        destroyDetailVideo();
        if (settings.browserMode === "chrome") Qt.openUrlExternally(u);
        else openInThemeBrowser(u);
    }

    function nextPage() {
        if (currentPage + 1 < totalPages()) { navSound.play(); currentPage++; selectedIndex = 0; rebuildPageSlice(); }
    }
    function prevPage() {
        if (currentPage > 0) { navSound.play(); currentPage--; selectedIndex = 0; rebuildPageSlice(); }
    }

    Component.onCompleted: {
        allGamesCache = fallbackCatalog.slice(0);
        rebuildGrid();
    }

    onVisibleChanged: {
        if (visible) {
            detailOpen = false;
            fullscreenVideo = false;
            destroyDetailVideo();
            focusZone = "grid";
            if (allGamesCache.length <= fallbackCatalog.length) fetchLiveApkPorts();
            storeRoot.forceActiveFocus();
        } else {
            destroyDetailVideo();
        }
    }

    Keys.onLeftPressed: {
        if (fullscreenVideo) return;
        if (detailOpen) {
            navSound.play();
            detailFocusBtn = (detailFocusBtn + 2) % 3;
            if (detailFocusBtn === 2 && detailVideoUrl === "") detailFocusBtn = 1;
            return;
        }
        navSound.play();
        if (focusZone === "grid") {
            if (selectedIndex % 3 === 0) {
                if (currentPage > 0) {
                    var targetRow = Math.floor(selectedIndex / 3);
                    prevPage();
                    selectedIndex = Math.max(0, Math.min(pageGridModel.count - 1, targetRow * 3 + 2));
                } else {
                    focusZone = "sidebar";
                }
            } else {
                selectedIndex = Math.max(0, selectedIndex - 1);
            }
        }
    }

    Keys.onRightPressed: {
        if (fullscreenVideo) return;
        if (detailOpen) {
            navSound.play();
            detailFocusBtn = (detailFocusBtn + 1) % 3;
            if (detailFocusBtn === 2 && detailVideoUrl === "") detailFocusBtn = 0;
            return;
        }
        navSound.play();
        if (focusZone === "sidebar") {
            activateSidebarEntry(sidebarFocusIdx);
            focusZone = "grid";
        } else if (pageGridModel.count > 0) {
            if (selectedIndex % 3 === 2 && currentPage + 1 < totalPages()) {
                var rRow = Math.floor(selectedIndex / 3);
                nextPage();
                selectedIndex = Math.max(0, Math.min(pageGridModel.count - 1, rRow * 3));
            } else {
                selectedIndex = Math.min(pageGridModel.count - 1, selectedIndex + 1);
            }
        }
    }

    Keys.onUpPressed: {
        if (fullscreenVideo) return;
        if (detailOpen) {
            if (detailVideoUrl !== "") { navSound.play(); detailFocusBtn = 2; }
            return;
        }
        navSound.play();
        if (focusZone === "sidebar") {
            moveSidebar(-1);
        } else if (selectedIndex >= 3) {
            selectedIndex -= 3;
        }
    }

    Keys.onDownPressed: {
        if (fullscreenVideo) return;
        if (detailOpen) {
            if (detailFocusBtn === 2) { navSound.play(); detailFocusBtn = 0; }
            return;
        }
        navSound.play();
        if (focusZone === "sidebar") {
            moveSidebar(1);
        } else if (pageGridModel.count > 0) {
            selectedIndex = Math.min(pageGridModel.count - 1, selectedIndex + 3);
        }
    }

    Keys.onBackPressed: {
        event.accepted = true;
        if (fullscreenVideo) closeFullscreenVideo();
        else if (detailOpen) { detailOpen = false; destroyDetailVideo(); focusZone = "grid"; backSfx.play(); }
        else if (focusZone === "sidebar") { focusZone = "grid"; backSfx.play(); }
        else { backSfx.play(); showHomeScreen(); }
    }
    Keys.onEscapePressed: {
        event.accepted = true;
        if (fullscreenVideo) closeFullscreenVideo();
        else if (detailOpen) { detailOpen = false; destroyDetailVideo(); focusZone = "grid"; backSfx.play(); }
        else { backSfx.play(); showHomeScreen(); }
    }
    Keys.onReleased: {
        if (typeof root !== "undefined" && typeof root.handleGlobalSleepCombo === "function") root.handleGlobalSleepCombo(event.key, false);
    }

    Keys.onPressed: {
        if (typeof root !== "undefined" && typeof root.handleGlobalSleepCombo === "function" && root.handleGlobalSleepCombo(event.key, true)) { event.accepted = true; return; }
        if (fullscreenVideo) {
            if ((api.keys.isCancel(event) || api.keys.isAccept(event)) && !event.isAutoRepeat) {
                event.accepted = true;
                closeFullscreenVideo();
            }
            return;
        }
        if (detailOpen) {
            if (api.keys.isCancel(event) && !event.isAutoRepeat) {
                event.accepted = true;
                detailOpen = false;
                destroyDetailVideo();
                focusZone = "grid";
                backSfx.play();
            } else if (api.keys.isAccept(event) && !event.isAutoRepeat) {
                event.accepted = true;
                if (detailFocusBtn === 2 && detailVideoUrl !== "") openFullscreenVideo();
                else if (detailFocusBtn === 1) toggleWishlist(detailGame.slug);
                else openDownloadPage();
            } else if (api.keys.isDetails(event) && !event.isAutoRepeat) {
                event.accepted = true;
                toggleWishlist(detailGame.slug);
            }
            return;
        }
        if (api.keys.isAccept(event) && !event.isAutoRepeat) {
            event.accepted = true;
            if (focusZone === "sidebar") {
                activateSidebarEntry(sidebarFocusIdx);
                focusZone = "grid";
            } else {
                openItemDetail(selectedIndex);
            }
        } else if (api.keys.isCancel(event) && !event.isAutoRepeat) {
            event.accepted = true;
            if (focusZone === "sidebar") {
                focusZone = "grid";
                backSfx.play();
            } else {
                backSfx.play();
                showHomeScreen();
            }
        } else if (api.keys.isDetails(event) && !event.isAutoRepeat) {
            event.accepted = true;
            if (selectedIndex >= 0 && selectedIndex < pageGridModel.count) {
                toggleWishlist(pageGridModel.get(selectedIndex).slug);
            }
        } else if (api.keys.isNextPage(event) && !event.isAutoRepeat) {
            event.accepted = true;
            nextPage();
        } else if (api.keys.isPrevPage(event) && !event.isAutoRepeat) {
            event.accepted = true;
            if (currentPage > 0) prevPage();
            else { focusZone = "sidebar"; navSound.play(); }
        }
    }

    Rectangle { anchors.fill: parent; color: storeRoot.pageBg }

    // Top Nintendo eShop Header
    Item {
        id: storeHeader
        anchors { top: parent.top; left: parent.left; right: parent.right }
        height: Math.round(screenheight * 0.115)

        Rectangle { anchors.fill: parent; color: storeRoot.eshopRed }

        Row {
            anchors { left: parent.left; leftMargin: screenmargin; verticalCenter: parent.verticalCenter }
            spacing: vpx(14)
            Item {
                width: vpx(32); height: vpx(32); anchors.verticalCenter: parent.verticalCenter
                Image { id: eshopBagLogo; anchors.fill: parent; source: "../assets/images/navigation/ns2_eshop.svg"; fillMode: Image.PreserveAspectFit; smooth: true; visible: false }
                ColorOverlay { anchors.fill: eshopBagLogo; source: eshopBagLogo; color: "#111111"; antialiasing: true }
            }
            Text { text: tr("Nintendo eShop"); color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.038); font.bold: true; anchors.verticalCenter: parent.verticalCenter }
            Text {
                text: storeRoot.selectedCategory !== "" ? ("· " + storeRoot.selectedCategory) : (storeRoot.activeSection === "wishlist" ? "· ★ Wish List" : "")
                color: "#FEE2E2"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.025); font.bold: true; anchors.verticalCenter: parent.verticalCenter
            }
        }
    }

    Item {
        anchors { top: storeHeader.bottom; bottom: storeFooter.top; left: parent.left; right: parent.right }

        // Left Controller-Navigable Sidebar with Bigger Fonts
        Rectangle {
            id: eshopSidebar
            anchors { top: parent.top; bottom: parent.bottom; left: parent.left }
            width: Math.round(parent.width * 0.24)
            color: storeRoot.sidebarBg
            border.width: 0

            ListView {
                id: sidebarList
                anchors { fill: parent; margins: vpx(14) }
                clip: true
                spacing: vpx(4)
                model: storeRoot.sidebarEntries
                currentIndex: storeRoot.sidebarFocusIdx

                delegate: Item {
                    width: sidebarList.width
                    height: modelData.kind === "header" ? vpx(40) : vpx(50)
                    property bool isActiveItem: (modelData.kind === "genre" && storeRoot.activeSection === "genres" && storeRoot.selectedCategory === modelData.cat)
                                             || (modelData.kind === "sort" && storeRoot.activeSection === "az")
                                             || (modelData.kind === "section" && storeRoot.activeSection === modelData.id)
                    property bool isKbFocused: storeRoot.focusZone === "sidebar" && index === storeRoot.sidebarFocusIdx

                    Rectangle {
                        visible: modelData.kind !== "header"
                        anchors.fill: parent
                        radius: vpx(8)
                        color: isActiveItem ? storeRoot.eshopRed : (isKbFocused ? storeRoot.cardBg : "transparent")
                        border.width: isKbFocused ? vpx(3) : 0
                        border.color: storeRoot.eshopRed
                    }

                    Text {
                        anchors {
                            left: parent.left
                            leftMargin: modelData.kind === "genre" ? vpx(24) : vpx(12)
                            verticalCenter: parent.verticalCenter
                        }
                        text: modelData.id === "wishlist" ? ("★ " + modelData.label) : modelData.label
                        color: modelData.kind === "header" ? storeRoot.eshopRed
                             : (isActiveItem ? "#FFFFFF" : storeRoot.textMain)
                        font.family: titleFont.name
                        font.pixelSize: modelData.kind === "genre" ? Math.round(screenheight * 0.027 * fontScale) : Math.round(screenheight * 0.031 * fontScale)
                        font.bold: isActiveItem || modelData.kind === "header" || isKbFocused
                    }

                    MouseArea {
                        anchors.fill: parent
                        enabled: modelData.kind !== "header"
                        onClicked: {
                            storeRoot.focusZone = "sidebar";
                            storeRoot.activateSidebarEntry(index);
                        }
                    }
                }
            }
        }

        // Right Games Grid (Red Selection Border strictly IN FRONT OF Artwork!)
        Item {
            anchors { top: parent.top; bottom: parent.bottom; left: eshopSidebar.right; right: parent.right; margins: vpx(20) }

            Text {
                visible: pageGridModel.count === 0
                anchors.centerIn: parent
                text: storeRoot.activeSection === "wishlist" ? tr("Your Wish List is empty. Press Y / ☆ to add titles.") : tr("No Nintendo eShop titles matched.")
                color: storeRoot.textMuted
                font.family: titleFont.name
                font.pixelSize: Math.round(screenheight * 0.025)
            }

            GridView {
                id: eshopGrid
                anchors.fill: parent
                clip: true
                cellWidth: Math.floor(width / 3)
                cellHeight: Math.floor(height / 2)
                model: pageGridModel

                delegate: Item {
                    width: eshopGrid.cellWidth
                    height: eshopGrid.cellHeight
                    property bool selected: storeRoot.focusZone === "grid" && index === storeRoot.selectedIndex
                    property bool wish: storeRoot.isWishlisted(model.slug)

                    Rectangle {
                        anchors { fill: parent; margins: vpx(8) }
                        radius: vpx(12)
                        color: storeRoot.cardBg
                        clip: true

                        // Clipped Artwork Container (z: 5)
                        Item {
                            id: artFrame
                            anchors { top: parent.top; left: parent.left; right: parent.right }
                            height: Math.round(parent.height * 0.56)
                            z: 5
                            clip: true

                            Image {
                                anchors.fill: parent
                                source: model.cover
                                fillMode: Image.PreserveAspectCrop
                                asynchronous: true
                                cache: true
                            }

                            Rectangle {
                                anchors { top: parent.top; left: parent.left; topMargin: vpx(8); leftMargin: vpx(8) }
                                height: vpx(24); width: srcBadgeLbl.implicitWidth + vpx(16); radius: vpx(6)
                                color: (model.sourceSite === "nswpedia" || model.portType === "switch") ? "#E60012" : "#2563EB"
                                Text {
                                    id: srcBadgeLbl
                                    anchors.centerIn: parent
                                    text: (model.sourceSite === "nswpedia" || model.portType === "switch") ? "NS SWITCH" : "PORT"
                                    color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true
                                }
                            }

                            Rectangle {
                                visible: wish
                                anchors { top: parent.top; right: parent.right; topMargin: vpx(8); rightMargin: vpx(8) }
                                width: vpx(30); height: vpx(30); radius: vpx(15)
                                color: "#E60012"
                                Text { anchors.centerIn: parent; text: "★"; color: "#FDE047"; font.pixelSize: vpx(16) }
                            }
                        }

                        // Metadata Text Area (z: 10)
                        Column {
                            anchors { top: artFrame.bottom; bottom: parent.bottom; left: parent.left; right: parent.right; margins: vpx(10) }
                            spacing: vpx(4)
                            z: 10
                            Text {
                                width: parent.width; text: model.title; color: storeRoot.textMain
                                font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.023); font.bold: true
                                elide: Text.ElideRight
                            }
                            Text {
                                width: parent.width; text: model.category + " · v" + model.version
                                color: storeRoot.eshopRed; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.018); font.bold: true
                                elide: Text.ElideRight
                            }
                            Text {
                                width: parent.width; text: model.desc
                                color: storeRoot.textMuted; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.017)
                                wrapMode: Text.WordWrap; maximumLineCount: 2; elide: Text.ElideRight
                            }
                        }

                        // RED SELECTION BORDER RENDERED IN FRONT OF ARTWORK (z: 25)
                        Rectangle {
                            anchors.fill: parent
                            radius: vpx(12)
                            color: "transparent"
                            border.width: selected ? vpx(5) : 1
                            border.color: selected ? storeRoot.eshopRed : storeRoot.dividerColor
                            z: 25
                        }

                        MouseArea {
                            anchors.fill: parent
                            onClicked: {
                                storeRoot.focusZone = "grid";
                                storeRoot.selectedIndex = index;
                                storeRoot.openItemDetail(index);
                            }
                        }
                    }
                }
            }
        }
    }

    // Bottom Nintendo eShop Footer
    Item {
        id: storeFooter
        anchors { bottom: parent.bottom; left: parent.left; right: parent.right; leftMargin: screenmargin; rightMargin: screenmargin }
        height: Math.round(screenheight * 0.088)
        Rectangle { anchors.top: parent.top; width: parent.width; height: 1; color: storeRoot.dividerColor }
        Image { anchors { left: parent.left; verticalCenter: parent.verticalCenter } width: vpx(36); height: vpx(26); source: "../assets/images/navigation/ns2_controller_glyph.svg"; fillMode: Image.PreserveAspectFit; smooth: true }
        Row {
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            spacing: vpx(20)
            Text { text: "Page " + (storeRoot.currentPage + 1) + "/" + storeRoot.totalPages() + " (L/R)"; color: storeRoot.textMuted; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.020); anchors.verticalCenter: parent.verticalCenter }
            Row { spacing: vpx(8); anchors.verticalCenter: parent.verticalCenter
                Rectangle { width: vpx(24); height: vpx(24); radius: width / 2; color: storeRoot.eshopRed; Text { anchors.centerIn: parent; text: "Y"; color: "#FFFFFF"; font.pixelSize: vpx(13); font.bold: true } }
                Text { text: tr("★ Wish List"); color: storeRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.021) }
            }
            Row { spacing: vpx(8); anchors.verticalCenter: parent.verticalCenter
                Rectangle { width: vpx(24); height: vpx(24); radius: width / 2; color: storeRoot.textMain; Text { anchors.centerIn: parent; text: "A"; color: storeRoot.pageBg; font.pixelSize: vpx(13); font.bold: true } }
                Text { text: tr("Details"); color: storeRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.021) }
            }
            Row { spacing: vpx(8); anchors.verticalCenter: parent.verticalCenter
                Rectangle { width: vpx(24); height: vpx(24); radius: width / 2; color: storeRoot.textMain; Text { anchors.centerIn: parent; text: "B"; color: storeRoot.pageBg; font.pixelSize: vpx(13); font.bold: true } }
                Text { text: tr("Back"); color: storeRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.021) }
                MouseArea { anchors.fill: parent; onClicked: { backSfx.play(); showHomeScreen(); } }
            }
        }
    }

    // GAME DETAIL MODAL WITH AUTO-PLAYING VIDEO & FULLSCREEN TOGGLE + STAR WISHLIST + DOWNLOAD
    Rectangle {
        visible: storeRoot.detailOpen
        anchors.fill: parent
        color: "#CC000000"
        z: 50

        MouseArea { anchors.fill: parent; onClicked: {} }

        Rectangle {
            anchors.centerIn: parent
            width: Math.round(parent.width * 0.86)
            height: Math.round(parent.height * 0.82)
            radius: vpx(18)
            color: storeRoot.cardBg
            border.width: vpx(3)
            border.color: storeRoot.eshopRed

            RowLayout {
                anchors { fill: parent; margins: vpx(24) }
                spacing: vpx(24)

                // Left: Media Frame (Auto-playing Video when available, else Cover Art; Select to Fullscreen!)
                Rectangle {
                    Layout.preferredWidth: Math.round(parent.width * 0.45)
                    Layout.fillHeight: true
                    radius: vpx(14)
                    color: "#090A0D"
                    clip: true
                    border.width: storeRoot.detailFocusBtn === 2 ? vpx(4) : 1
                    border.color: storeRoot.detailFocusBtn === 2 ? storeRoot.eshopRed : storeRoot.dividerColor

                    Image {
                        anchors.fill: parent
                        source: storeRoot.detailGame.cover || ""
                        fillMode: Image.PreserveAspectCrop
                    }

                    Item {
                        id: videoInlineHost
                        anchors.fill: parent
                        visible: storeRoot.detailVideoUrl !== ""
                    }

                    Rectangle {
                        visible: storeRoot.detailVideoUrl !== ""
                        anchors { bottom: parent.bottom; left: parent.left; right: parent.right }
                        height: vpx(38)
                        color: "#AA000000"
                        Row {
                            anchors.centerIn: parent; spacing: vpx(8)
                            Text { text: "▶"; color: "#FFFFFF"; font.pixelSize: vpx(15) }
                            Text {
                                text: storeRoot.detailFocusBtn === 2 ? tr("Press A / Click for Fullscreen Video") : tr("Playing Trailer · Tap for Fullscreen")
                                color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: vpx(14); font.bold: true
                            }
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        enabled: storeRoot.detailVideoUrl !== ""
                        onClicked: storeRoot.openFullscreenVideo()
                    }
                }

                // Right: Game Info, Real Description, Download & Star Wish List
                ColumnLayout {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    spacing: vpx(12)

                    Text {
                        Layout.fillWidth: true
                        text: storeRoot.detailGame.title || ""
                        color: storeRoot.textMain
                        font.family: titleFont.name
                        font.pixelSize: Math.round(screenheight * 0.036)
                        font.bold: true
                        wrapMode: Text.WordWrap
                    }

                    Text {
                        text: (storeRoot.detailGame.category || "Action") + " · v" + (storeRoot.detailGame.version || "1.0") + " · " + (storeRoot.detailGame.dev || "APKPorts")
                        color: storeRoot.eshopRed
                        font.family: titleFont.name
                        font.pixelSize: Math.round(screenheight * 0.022)
                        font.bold: true
                    }

                    Flickable {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        contentWidth: width
                        contentHeight: detailDescText.implicitHeight + vpx(12)
                        clip: true

                        Text {
                            id: detailDescText
                            width: parent.width
                            text: storeRoot.detailDesc || storeRoot.detailGame.desc || ""
                            color: storeRoot.textMain
                            font.family: titleFont.name
                            font.pixelSize: Math.round(screenheight * 0.024)
                            wrapMode: Text.WordWrap
                            lineHeight: 1.4
                        }
                    }

                    Row {
                        Layout.fillWidth: true
                        spacing: vpx(14)

                        // Big Orange/Red Download Button (sends to apkports download page)
                        Rectangle {
                            width: vpx(210); height: vpx(50); radius: vpx(12)
                            color: storeRoot.eshopRed
                            border.width: storeRoot.detailFocusBtn === 0 ? vpx(3) : 0
                            border.color: "#FFFFFF"
                            Text {
                                anchors.centerIn: parent
                                text: tr("Download")
                                color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.026); font.bold: true
                            }
                            MouseArea { anchors.fill: parent; onClicked: storeRoot.openDownloadPage() }
                        }

                        // Wish List Button with Star
                        Rectangle {
                            width: vpx(230); height: vpx(50); radius: vpx(12)
                            color: storeRoot.isWishlisted(storeRoot.detailGame.slug) ? storeRoot.eshopRed : storeRoot.sidebarBg
                            border.width: storeRoot.detailFocusBtn === 1 ? vpx(3) : 1
                            border.color: storeRoot.detailFocusBtn === 1 ? storeRoot.eshopRed : storeRoot.dividerColor
                            Text {
                                anchors.centerIn: parent
                                text: storeRoot.isWishlisted(storeRoot.detailGame.slug) ? tr("★ Wishlisted") : tr("☆ Add to Wish List")
                                color: storeRoot.isWishlisted(storeRoot.detailGame.slug) ? "#FFFFFF" : storeRoot.textMain
                                font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.024); font.bold: true
                            }
                            MouseArea { anchors.fill: parent; onClicked: storeRoot.toggleWishlist(storeRoot.detailGame.slug) }
                        }
                    }
                }
            }
        }
    }

    // FULLSCREEN VIDEO PLAYER OVERLAY
    Rectangle {
        visible: storeRoot.fullscreenVideo
        anchors.fill: parent
        color: "#000000"
        z: 120

        Image {
            anchors.fill: parent
            source: storeRoot.detailGame.cover || ""
            fillMode: Image.PreserveAspectFit
            opacity: 0.4
        }

        Item {
            id: fullscreenVideoHost
            anchors.fill: parent
        }

        Rectangle {
            anchors { top: parent.top; right: parent.right; margins: vpx(24) }
            width: vpx(190); height: vpx(44); radius: vpx(22)
            color: "#CC000000"; border.width: 2; border.color: "#FFFFFF"
            Text { anchors.centerIn: parent; text: tr("B · Exit Fullscreen"); color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: vpx(15); font.bold: true }
            MouseArea { anchors.fill: parent; onClicked: storeRoot.closeFullscreenVideo() }
        }
    }
}
